<template lang="">
  <section class="container-fluid d-none d-sm-none d-md-block py-5" id="Ahora-aceptamos">
    <div class="container">
      <div class="row">
        <div class="col-5">
          <h2 class="text-light fw-bold display-5">
            Ahora aceptamos
          </h2>
        </div>
        <div class="col-7">
          <div class="row text-light">
            <div class="col-2">
              <i class="fab fa-cc-mastercard fa-4x"></i>
            </div>
            <div class="col-2">
              <i class="fab fa-cc-visa fa-4x"></i>
            </div>
            <div class="col-2">
              <i class="fab fa-cc-amex fa-4x"></i>
            </div>
            <div class="col-2">
              <i class="fab fa-cc-diners-club fa-4x"></i>
            </div>
            <div class="col-2">
              <i class="fab fa-cc-paypal fa-4x"></i>
            </div>
            <div class="col-2">
              <i class="fab fa-cc-discover fa-4x"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
