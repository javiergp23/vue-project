<template lang="">
  <footer class="py-5 px-5">
    <img src="../assets/img/logo-footer.png" class="mx-auto d-block" alt="suricata" />
  </footer>
</template>