<template lang="">
  <h1>
    Vista de contacto
  </h1>

  <div>
    <router-link class="btn btn-success" to="/">Volver al inicio</router-link>
  </div>
</template>